function Header() {

    return (
        <div className="header">
                This is made in React
        </div>
    );
}
export default Header;